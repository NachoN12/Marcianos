<!DOCTYPE html>
<?php
  include('cabecera.html');
  include('conexion.php');
 $elimini = $_POST['id'];

 $query = "SELECT nombre FROM pasajero WHERE id= '$elimini'";

 $result = $link->query($query);
 if($row = $result->fetch_assoc()){
 	$nombre = $row['nombre'];
	?>
	<form method="POST" action="mmar.php">
	<input type="hidden" name="id" value="<?php echo $elimini; ?>">
	<input class="form-control" name="modificar_marciano" type="text" placeholder="<?php echo $nombre; ?>"><br>
	<button type="submit" class="btn btn-default">Submit</button>
	</form>

	<?php
}
else{
	?>
	<div class="alert alert-warning">
	  	<strong>Error!</strong>	Hubo un problema al consultar la base con el id indicado.
	</div>
	<?php
			      	}
?>
</html>